// Known XSS attack patterns (simplified version)
const xssPatterns = [
    /<script>.*?<\/script>/i,
    /onerror\s*=\s*["'].*?["']/i,
    /javascript:/i,
    /<iframe.*?>.*?<\/iframe>/i
  ];
  
  // Function to scan for XSS payloads
  function detectXSS() {
    let detectedAttacks = [];
  
    // Scan URL parameters for reflected XSS
    let urlParams = new URLSearchParams(window.location.search);
    urlParams.forEach((value, key) => {
      xssPatterns.forEach(pattern => {
        if (pattern.test(value)) {
          detectedAttacks.push({ type: "Reflected XSS", param: key, payload: value });
        }
      });
    });
  
    // Scan DOM elements for DOM-based XSS
    document.querySelectorAll("*").forEach(element => {
      xssPatterns.forEach(pattern => {
        if (element.innerHTML && pattern.test(element.innerHTML)) {
          detectedAttacks.push({ type: "DOM XSS", element: element.tagName, payload: element.innerHTML });
        }
      });
    });
  
    // Send detected attacks to background script
    if (detectedAttacks.length > 0) {
      chrome.runtime.sendMessage({ action: "xssDetected", attacks: detectedAttacks });
    }
  }
  
  // Run XSS detection when the page loads
  detectXSS();
  