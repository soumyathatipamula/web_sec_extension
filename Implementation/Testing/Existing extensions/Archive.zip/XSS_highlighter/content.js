const attackVectors = [
    /<script.*?>.*?<\/script>/gi, // Inline <script> injections
    /javascript:/gi, // JavaScript pseudo-protocol
    /on\w+=/gi, // Event handler attributes (onload, onerror, etc.)
    /<video[^>]*onerror=.*?>/gi, // <video> XSS
    /<form[^>]*formaction=.*?>/gi, // <form> hijacking
    /<svg[^>]*onload=.*?>/gi, // <svg> payloads
    /document\.(cookie|write|location)/gi, // DOM-based attacks
];

function detectXSS() {
    let pageContent = document.body.innerHTML;
    let found = false;

    attackVectors.forEach((pattern) => {
        let matches = pageContent.match(pattern);
        if (matches) {
            found = true;
            console.warn("Potential XSS Detected:", matches);
            highlightMatches(pattern);
        }
    });

    if (found) {
        alert("⚠️ XSS Attack Detected! Check console for details.");
    }
}

function highlightMatches(pattern) {
    let elements = document.body.getElementsByTagName('*');
    for (let element of elements) {
        if (element.innerHTML.match(pattern)) {
            element.style.backgroundColor = "red";
        }
    }
}

detectXSS();
