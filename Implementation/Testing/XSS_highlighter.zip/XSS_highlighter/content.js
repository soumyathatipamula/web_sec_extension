const attackVectors = [
    /<script>.*?<\/script>/i,
    /javascript:/i,
    /on\w+\s*=\s*["'].*?["']/i,
    /<video\s+[^>]*onerror\s*=\s*["'].*?["'][^>]*>/i,
    /<form\s+[^>]*formaction\s*=\s*["'].*?["'][^>]*>/i,
    /<svg\s+[^>]*onload\s*=\s*["'].*?["'][^>]*>/i,
    /document\.(cookie|write|location)/i

];

function detectXSS() {
    let pageContent = document.body.innerHTML;
    let found = false;

    attackVectors.forEach((pattern) => {
        let matches = pageContent.match(pattern);
        if (matches) {
            found = true;
            console.warn("Potential XSS Detected:", matches);
            highlightMatches(pattern);
            console.log(matches);
        }
    });

    if (found) {
        alert("⚠️ XSS Attack Detected! Check console for details.");
    }
}

function highlightMatches(pattern) {
    let elements = document.body.getElementsByTagName('*');
    for (let element of elements) {
        if (element.innerHTML.match(pattern)) {
            element.style.backgroundColor = "red";
        }
    }
}

detectXSS();
