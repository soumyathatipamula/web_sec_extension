chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "showNotification") {
      chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "XSS Alert!",
          message: message.message
      });
  }
});
