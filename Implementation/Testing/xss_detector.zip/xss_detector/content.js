console.log("🔍 XSS Content Script Loaded.");

// Request attack vectors from background.js
chrome.runtime.sendMessage({ action: "getAttackVectors" }, (response) => {
    if (response && response.vectors) {
        checkForXSS(response.vectors);
    } else {
        console.warn("⚠️ No attack vectors received.");
    }
});

// Function to check for XSS attack vectors
function checkForXSS(vectors) {
    console.log("🔍 Scanning for XSS attacks...");

    const allElements = document.querySelectorAll("*");

    allElements.forEach((element) => {
        // Check for dangerous tags
        Object.values(vectors.tags || {}).flat().forEach((xssTag) => {
            if (element.outerHTML.includes(xssTag)) {
                alertUser("⚠️ XSS Detected! Dangerous tag found: " + xssTag);
            }
        });

        // Check for dangerous attributes
        Object.values(vectors.attributes || {}).flat().forEach((xssAttr) => {
            if (element.hasAttribute(xssAttr)) {
                alertUser(`⚠️ Suspicious Attribute Found: ${xssAttr} in <${element.tagName.toLowerCase()}>`);
            }
        });

        // Check for dangerous payloads
        Object.values(vectors.payloads || {}).flat().forEach((xssPayload) => {
            if (element.innerHTML.includes(xssPayload) || element.outerHTML.includes(xssPayload)) {
                alertUser("⚠️ Malicious Payload Detected: " + xssPayload);
            }
        });
    });
}

// Function to alert user
function alertUser(message) {
    console.warn(message);
    chrome.runtime.sendMessage({ action: "showNotification", message });
}
