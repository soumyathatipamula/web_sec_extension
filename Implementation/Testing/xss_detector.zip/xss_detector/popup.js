document.addEventListener("DOMContentLoaded", function () {
  setTimeout(() => {
      const scanButton = document.getElementById("scan");

      if (scanButton) {
          scanButton.addEventListener("click", () => {
              chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                  chrome.scripting.executeScript({
                      target: { tabId: tabs[0].id },
                      function: scanForXSS
                  });
              });
          });
      } else {
          console.error("⚠️ Scan button not found in popup.html.");
      }
  }, 500);
});

function scanForXSS() {
  chrome.runtime.sendMessage({ action: "getAttackVectors" }, (response) => {
      if (response && response.vectors) {
          checkForXSS(response.vectors);
      }
  });
}
