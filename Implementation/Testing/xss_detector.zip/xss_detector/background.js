chrome.runtime.onInstalled.addListener(() => {
  console.log("✅ XSS Detector Installed.");
});

// Load XSS attack vectors from JSON
async function loadAttackVectors() {
  try {
      const response = await fetch(chrome.runtime.getURL("xss_vectors.json"));
      if (!response.ok) {
          throw new Error(`❌ JSON Fetch Error: ${response.status}`);
      }
      const attackVectors = await response.json();
      console.log("✅ XSS Attack Vectors Loaded:", attackVectors);
      return attackVectors;
  } catch (error) {
      console.error("❌ Error loading attack vectors:", error);
      return {};  // Prevent crashes by returning an empty object
  }
}

// Listen for content script requests
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getAttackVectors") {
      loadAttackVectors().then(vectors => sendResponse({ vectors })).catch(error => {
          console.error("❌ Error sending vectors:", error);
          sendResponse({ vectors: {} });
      });
      return true;  // Required for async responses
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "showNotification") {
      chrome.notifications.create({
          type: "basic",
          iconUrl: "icon.png",
          title: "🚨 XSS Alert!",
          message: message.message
      });
  }
});
