const attackVectors = [
    /<script.*?>.*?<\/script>/gi, 
    /javascript:/gi, 
    /on\w+=/gi, 
    /<video[^>]*onerror=.*?>/gi, 
    /<form[^>]*formaction=.*?>/gi, 
    /<svg[^>]*onload=.*?>/gi, 
    /document\.(cookie|write|location)/gi
];

function detectXSS() {
    let pageContent = document.body.innerHTML;
    let xssDetected = false;
    let foundMatches = [];

    attackVectors.forEach((pattern) => {
        let matches = pageContent.match(pattern);
        if (matches) {
            xssDetected = true;
            foundMatches = foundMatches.concat(matches);
            highlightMatches(pattern);
        }
    });

    if (xssDetected) {
        alert("🚨 XSS Attack Detected! Check console for details.");
        console.warn("XSS Detected:", foundMatches);
    }
}

function highlightMatches(pattern) {
    let elements = document.body.getElementsByTagName('*');
    for (let element of elements) {
        if (element.innerHTML.match(pattern)) {
            element.style.backgroundColor = "red";
        }
    }
}

detectXSS();